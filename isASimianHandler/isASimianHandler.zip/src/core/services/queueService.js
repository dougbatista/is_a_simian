
const { queueParams } = require("../models/queueModel");
const { arrayGrouper } = require("../utils/matrixBuilder");
const SQS = require("../config/sqsConfig")();

async function queueToDNAStore(dnaResults = {}) {
  const groupedArrays = arrayGrouper(dnaResults);
  queueParams.MessageBody = JSON.stringify(groupedArrays);
  await SQS.sendMessage(queueParams).promise();
  // sqs.sendMessage(queueParams, function (err, data) {
  //   if (err) {
  //     console.log("Queue post error", err);
  //   } else {
  //     console.log("Success Queue", data.MessageId);
  //   }
  // });
}

module.exports = {
  queueToDNAStore
};
